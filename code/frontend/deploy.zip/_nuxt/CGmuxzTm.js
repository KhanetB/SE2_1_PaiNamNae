import{a2 as a,g as o,p as t}from"./BAphwQfp.js";const i=a((n,r)=>{const e=o("user").value;if(!o("token").value)return t("/login");if(!e||e.role!=="ADMIN")return t("/")});export{i as default};
