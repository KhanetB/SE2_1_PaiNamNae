import"./BAphwQfp.js";const e=window.setInterval;export{e as s};
