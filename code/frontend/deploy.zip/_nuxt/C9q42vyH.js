import{a2 as o,g as t,p as a}from"./BAphwQfp.js";const s=o(e=>{if(!t("token").value&&e.path!=="/login")return a("/login")});export{s as default};
